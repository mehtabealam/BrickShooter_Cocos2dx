- cocos2d-x version:
- devices test on:
- developing environments
   - NDK version:
   - Xcode version:
   - VS version:
   - browser type and version:

Steps to Reproduce:

1. 
2. 
