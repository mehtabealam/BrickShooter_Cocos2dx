// precompiled header
// include here heavy headers which are included in many files
// this will speed-up build a lot

#include "cocos2d.h"
